<?php
/*
 * @author Sachin R K
 * @date 30-04-2012
 * @copyright Mobiuso LLC
 */
class PasswordFormats
{
	static $PLAIN_TEXT = 0;
	static $HASHED = 1;
	static $ENCRYPTED = 2;
} 

?>