<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
include_once '/Response.php';
include_once '../Utils/ResponseManager.php';

$obj = new ResponseManager;
$obj->createResponse('0','','32');

?>
